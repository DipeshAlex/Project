<style>
  body{
    background-image: url('images/background/bg5.jpg');
  }
</style>
<header id="default_header" class="header_style_1">
 
  <!-- header bottom -->
  <div class="header_bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
          <!-- logo start -->
          <div class="logo"> <a href="home"><img src="images/logos/lg.png" alt="logo"></a> </div>
          <!-- logo end -->
        </div>
        <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12" >
          <!-- menu start -->
          <div class="menu_side">
            <div id="navbar_menu" style ="background-color=#211a59"> 
              <ul class="first-ul">
                <li> <a class="" href="home">Home</a> </li>
                <li> <a class="" href="categories">Categories</a></li>
                  <!-- <ul>
                    <li><a href="our_courses">Our Courses</a></li>
                    <li><a href="our_courses">Our Courses</a></li>
                    <li><a href="our_languages">Our Languages</a></li>
                     <li><a href="shop_detail">Details</a></li>
                  </ul> -->
                
                <li> <a href="blog">Blog</a></li>
             
                <li> <a>Pages</a>
                  <ul>
                    <li><a href="faq">Faq</a></li>
                    <li><a href="privacy_policy">Privacy Policy</a></li>
                    <!-- <li><a href="error">Error 404</a></li> -->
                  </ul>
                </li>
                
                <li><a href="cart.">Cart</a>
                <ul><li><a href="checkout">Checkout</a></li></ul></li> 
                <li> <a href="contact">Contact</a> </li>
                <li><a href="about_us">About Us</a></li>  
                <li><a href="customer_login">Login</a></li>  
              </ul>
            </div>
            <div class="search_icon">
              <ul>
                <li><a href="#" data-toggle="modal" data-target="#search_bar"><i class="fa fa-search" aria-hidden="true"></i></a></li>
              </ul>
            </div>
          </div>
          <!-- menu end -->
        </div>
      </div>
    </div>
  </div>
  <!-- header bottom end -->
</header>
<!-- end header -->

<?php



?>