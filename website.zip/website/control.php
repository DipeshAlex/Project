<?php

include_once('../admin/model.php');

class control extends model
{
    function __construct()
    {
        session_start();

        model ::__construct();

       

        $url=$_SERVER['PATH_INFO'];

        switch($url)
        {
            case '/about_us':
            include_once('about_us.php');
            break;  

            case '/blog':
            include_once('blog.php');
            break;

            case '/cart':
            include_once('cart.php');
            break;

            case '/categories':
            $arr_categories=$this->select('categories');   
            include_once('categories.php');
            break;

            case '/checkout':
            include_once('checkout.php');
            break;  

            case '/contact':
            include_once('contact.php');
            break;  

            case '/customer_login':
                if(isset($_REQUEST['submit']))
				{
					
					$email=$_REQUEST['email'];
					$password=md5($_REQUEST['password']);	
					$where=array("email"=>$email,"password"=>$password);
					
					$res=$this->select_where('customer',$where);
					$chk=$res->num_rows; // check result by rows

					if($chk==1)
					{
						$fetch=$res->fetch_object();
						$_SESSION['cust_id']=$fetch->cust_id;
						$_SESSION['name']=$fetch->name;
						
						echo "<script> 
						alert('Login Success');
						window.location='customer_login';
						</script>";
					}
					else
					{
						echo "<script> 
						alert('Login failed due to wrong creadential');
						window.location='customer_login';
						</script>";
					}	
				}
				include_once('customer_login.php');
			break;
			
			case '/logout':
				
				unset($_SESSION['cust_id']);
				unset($_SESSION['name']);
				echo "<script> 
						alert('Logout Success');
						window.location='customer_login';
						</script>";
				
			break;
            include_once('customer_login.php');
            break;

            case '/faq':
            include_once('faq.php');
            break;

            case '/home':
            include_once('home.php');
            break;

            case '/our_courses':
            include_once('our_courses.php');
            break;
            
            case '/our_languages':
            include_once('our_languages.php');
            break;

            case '/privacy_policy':
            include_once('privacy_policy.php');
            break;

            case '/registration':
                // $arr_registration=$this->select('customer'); 
                //  $arr_countries=$this->select('countries');
                 if(isset($_REQUEST['submit']))
                 {
                     $name=$_REQUEST['name'];
                     $email=$_REQUEST['email'];
                     $password=$_REQUEST['password'];
                     $gender=$_REQUEST['gender'];
                     $mobile=$_REQUEST['mobile'];

                     $img=$_FILES['img']['name'];
                     $path='user/images/admin/'.$img;
                     $copy_file=$_FILES['img']['tmp_name'];
                     move_uploaded_file($copy_file,$path);
                      
                     $country=$_REQUEST['country'];

                     $created_at=date("Y-m-d H:i:s");
                     $updated_at=date("Y-m-d H:i:s");

                     $arr=array("name"=>$name,"email"=>$email,"password"=>$password,"gender"=>$gender,"mobile"=>$mobile,
                     "img"=>$img,"country"=>$country,"created_at"=>$created_at,"updated_at"=>$updated_at);

                     $res=$this->insert('customer',$arr);
                     if($res)
                     {
						echo "<script> 
						alert('Signup submit Success');
						window.location='registration';
						</script>";
					}
					else
					{
						echo "<script> 
						alert('failed');
						window.location='registration';
						</script>";
					}	
                 }
 
            include_once('registration.php');
            break;

            case '/shop_detail':
            include_once('shop_detail.php');
            break;

            default:
            include_once('error.php');
            break;
        }
    }




}

$obj=new control;


?>